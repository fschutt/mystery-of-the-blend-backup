nl.atmind.blender.file.jar contains java classes + source code to interpreter blender files.
it was written to support an article placed in BlenderArt magazine.

usage:

java -jar nl.atmind.blender.file.jar <BLEND-FILE>

output will be directed to your console (sorry for that)
to write it to an xml file you sould use: 

java -jar nl.atmind.blender.file.jar suzy.blend >suzy.xml

Feel free to use the code, change and adapt the code, just mention me as the source
Jeroen Bakker
j.bakker@atmind.nl
 