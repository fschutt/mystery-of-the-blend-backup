java -jar nl.atmind.blender.file.jar suzy.blend >suzy.xml
